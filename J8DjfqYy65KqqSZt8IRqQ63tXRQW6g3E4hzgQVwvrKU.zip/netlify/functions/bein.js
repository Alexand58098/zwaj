// 🔑 TifoTV beIN Bypass — Netlify Function (Smart v2)
// =====================================================
// يكتشف تلقائياً المشغّل الصحيح لكل قناة (daddy2/3/4/5)
// عبر جلب iframe الحقيقي من dlhd.pk
// =====================================================

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-Control-Allow-Headers": "*",
    "Access-Control-Expose-Headers": "*",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors, body: "" };
  }

  const params = event.queryStringParameters || {};
  const id = params.id;
  const proxyTarget = params.proxy;

  try {
    if (proxyTarget) {
      return await proxyHls(proxyTarget, cors, event);
    }

    if (!id) {
      return jsonRes({
        status: "ok",
        name: "TifoTV Smart Bypass v2",
        usage: { "Get stream": "?id=91", "Get JSON": "?id=91&json=1" },
      }, cors);
    }

    // ===== STEP 1: Get the correct iframe URL from dlhd.pk =====
    // (different channels use different player versions: daddy2/3/4/5)
    let playerUrl = null;
    try {
      const dlhdResp = await fetch(`https://dlhd.pk/stream/stream-${encodeURIComponent(id)}.php`, {
        headers: {
          "Referer": "https://dlhd.pk/",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
        // Add timeout via AbortController
        signal: AbortSignal.timeout(8000),
      });
      if (dlhdResp.ok) {
        const dlhdHtml = await dlhdResp.text();
        const iframeMatch = dlhdHtml.match(/iframe\s+src=["']([^"']+)["']/i);
        if (iframeMatch) playerUrl = iframeMatch[1];
      }
    } catch (e) { /* fall through to defaults */ }

    // Fallback: try known player versions in order
    const playerCandidates = playerUrl
      ? [playerUrl]
      : [
          `https://hamis.romponalis.st/premiumtv/daddy4.php?id=${id}`,
          `https://hamis.romponalis.st/premiumtv/daddy5.php?id=${id}`,
          `https://hamis.romponalis.st/premiumtv/daddy3.php?id=${id}`,
          `https://hamis.romponalis.st/premiumtv/daddy2.php?id=${id}`,
        ];

    // ===== STEP 2: Try each player and extract m3u8 =====
    let m3u8 = null;
    let usedPlayer = null;
    let lastError = null;

    for (const purl of playerCandidates) {
      try {
        const r = await fetch(purl, {
          headers: {
            "Referer": "https://dlhd.pk/",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml",
          },
          signal: AbortSignal.timeout(8000),
        });
        if (!r.ok) { lastError = `player ${r.status}`; continue; }
        const html = await r.text();
        // Extract base64 m3u8 URL
        const m = html.match(/atob\(['"]([A-Za-z0-9+/=_-]+)['"]\)/);
        if (!m) { lastError = "no m3u8 in player"; continue; }
        const candidate = Buffer.from(m[1], "base64").toString("utf8");
        // Verify it's a valid playlist
        const test = await fetch(candidate, {
          headers: { "User-Agent": "Mozilla/5.0" },
          signal: AbortSignal.timeout(5000),
        });
        if (test.ok) {
          const body = await test.text();
          if (body.includes("#EXTM3U")) {
            m3u8 = candidate;
            usedPlayer = purl.match(/daddy\d+/)?.[0] || "unknown";
            break;
          }
        }
        lastError = `stream ${test.status}`;
      } catch (e) {
        lastError = e.message;
      }
    }

    if (!m3u8) {
      return jsonRes({
        error: "Could not extract working m3u8 for channel " + id,
        detail: lastError,
        hint: "This channel may be temporarily unavailable. Try another channel or wait for live event start."
      }, cors, 502);
    }

    if (params.json === "1") {
      const host = `${event.headers["x-forwarded-proto"] || "https"}://${event.headers.host}`;
      return jsonRes({
        id, m3u8, player: usedPlayer,
        proxied: `${host}/.netlify/functions/bein?proxy=${encodeURIComponent(m3u8)}`,
      }, cors);
    }

    return await proxyHls(m3u8, cors, event);

  } catch (e) {
    return jsonRes({ error: String(e), stack: e.stack }, cors, 500);
  }
};

// =====================================================
async function proxyHls(target, cors, event) {
  // Choose appropriate Referer based on host
  let referer = "https://hamis.romponalis.st/";
  if (target.includes("dlhd.pk")) referer = "https://dlhd.pk/";
  else if (target.includes("phantemlis")) referer = "https://hamis.romponalis.st/";

  const upstream = await fetch(target, {
    headers: {
      "Referer": referer,
      "User-Agent": "Mozilla/5.0",
      "Origin": new URL(referer).origin,
    },
    signal: AbortSignal.timeout(10000),
  });

  // Detect Cloudflare block (DaddyLive segments host is sometimes blocked)
  if (upstream.status === 403) {
    const sample = await upstream.text();
    if (sample.includes("Cloudflare") || sample.includes("Website Access Blocked")) {
      return {
        statusCode: 502,
        headers: { ...cors, "Content-Type": "application/json" },
        body: JSON.stringify({
          error: "Upstream blocked by Cloudflare",
          host: new URL(target).host,
          note: "DaddyLive's video host has been temporarily blocked. Use live match channels (matches group) instead.",
        }),
      };
    }
  }

  const ct = (upstream.headers.get("content-type") || "").toLowerCase();
  const isPlaylist = ct.includes("mpegurl") || ct.includes("vnd.apple") ||
                     target.includes(".m3u8") || ct.includes("text/plain");

  if (!isPlaylist) {
    const buf = Buffer.from(await upstream.arrayBuffer());
    return {
      statusCode: upstream.status,
      headers: {
        ...cors,
        "Content-Type": upstream.headers.get("content-type") || "application/octet-stream",
        "Cache-Control": "no-cache",
      },
      body: buf.toString("base64"),
      isBase64Encoded: true,
    };
  }

  let text = await upstream.text();
  const base = target.replace(/[?#].*$/, "").replace(/\/[^\/]*$/, "/");
  const host = `${event.headers["x-forwarded-proto"] || "https"}://${event.headers.host}`;
  const proxyBase = `${host}/.netlify/functions/bein?proxy=`;

  text = text.split("\n").map(line => {
    const trimmed = line.trim();
    if (!trimmed) return line;
    if (trimmed.startsWith("#")) {
      return line.replace(/URI="([^"]+)"/g, (_, u) => {
        const abs = new URL(u, base).href;
        return `URI="${proxyBase}${encodeURIComponent(abs)}"`;
      });
    }
    const abs = new URL(trimmed, base).href;
    return `${proxyBase}${encodeURIComponent(abs)}`;
  }).join("\n");

  return {
    statusCode: upstream.status,
    headers: {
      ...cors,
      "Content-Type": "application/vnd.apple.mpegurl",
      "Cache-Control": "no-cache, max-age=2",
    },
    body: text,
  };
}

function jsonRes(obj, cors, status = 200) {
  return {
    statusCode: status,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify(obj, null, 2),
  };
}
